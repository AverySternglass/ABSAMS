//======================================================================== 
// Package			: The Connective Tissue
// Authors			: Pradeep Setlur
// Start Date		: Wed Feb 18 2004
// Compiler			: Microsoft Visual C++ 6.0
// Acknowledgements : Biomimetic and Cognitive Robotics Laboratory,
//                    Brooklyn College, CUNY.
//                    Defense Advanced Research Projects Agency
// ----------------------------------------------------------------------  
// File: Assembly.cpp
// Implementation of the class Assembly.
//========================================================================  


#include "Cement.hpp"


//============================================================
// Assembly::Assembly
//============================================================

Assembly::Assembly(){}
	// Default Constructor


//============================================================
// Assembly::Assembly
//============================================================

Assembly::Assembly(int assemblyNumber, const char *mhaFile)
	// Constructor
{
	
	FILE *mhaFilePtr;
	char header[10];
	double xpos,ypos,zpos;
	double dimensionA, dimensionB, dimensionC;
	double orientationI, orientationJ, orientationK;
	double uAxisL,uAxisM,uAxisN;
	Muscle *musclePtr;
	Surface *surfacePtr;
	int i;
	int mhuNumber;
	int type;
	int anchor;

	d_assemblyNumber = assemblyNumber;
	if((mhaFilePtr = fopen(mhaFile,"r")) == NULL)
		throw Status(3);
	else
	{
		fscanf(mhaFilePtr,"%s", header);
		fscanf(mhaFilePtr,"%d", &d_numMHUnits);
		cout << "Number of MH Units in the Assembly: " << d_numMHUnits << endl;
		fscanf(mhaFilePtr,"%s", header);
		fscanf(mhaFilePtr,"%d", &d_numSurfaces);

		fscanf(mhaFilePtr,"%s", header);
		fscanf(mhaFilePtr,"%d", &d_assemblyType);
		
		double muscleDensity= g_cephMuscleDensity;
		if(d_assemblyType == 1) muscleDensity= g_EAP1MuscleDensity;
		if(d_assemblyType == 2) muscleDensity= g_EAP2MuscleDensity;
		

		for (i = 0; i < 15; i++)
			fscanf(mhaFilePtr,"%s", header);

		for ( i=0; i < d_numMHUnits; i++)
		{
			fscanf(mhaFilePtr,"%d", &mhuNumber);
			fscanf(mhaFilePtr,"%d", &type);
			fscanf(mhaFilePtr,"%d", &anchor);
			fscanf(mhaFilePtr,"%lf%lf%lf", &dimensionA,&dimensionB,&dimensionC);
			fscanf(mhaFilePtr,"%lf%lf%lf", &xpos,&ypos,&zpos);
			fscanf(mhaFilePtr,"%lf%lf%lf", &orientationI,&orientationJ,&orientationK);
			fscanf(mhaFilePtr,"%lf%lf%lf", &uAxisL,&uAxisM,&uAxisN);
			
			if(type == 1)
			{
				musclePtr = new Cylinder( mhuNumber, dimensionA, dimensionB,
									Vector(xpos,ypos,zpos),
									Vector(orientationI,orientationJ,orientationK),
									Vector(uAxisL,uAxisM,uAxisN), muscleDensity);
				if(anchor == 1) musclePtr->setAnchor();
				d_memberMHUnits.addElement(musclePtr);
			}

			if(type == 2)
			{
				musclePtr = new Box(mhuNumber, dimensionA, dimensionB, dimensionC,
									Vector(xpos,ypos,zpos),
									Vector(orientationI,orientationJ,orientationK),
									Vector(uAxisL,uAxisM,uAxisN), muscleDensity);
				if(anchor == 1) musclePtr->setAnchor();
				d_memberMHUnits.addElement(musclePtr);
			}

		//	else
		//	{
		//		cout << "MH Unit " << mhuNumber << " cannot be created in ver 1.0" << endl;
		//		exit(0);
		//	}
		}
		for (i = 0; i < d_numSurfaces; i++)
		{
			surfacePtr = new Surface(i, this, mhaFilePtr);
			d_memberSurfaces.addElement(surfacePtr);
		}
		fclose(mhaFilePtr);
	}
}

//============================================================
// Assembly::~Assembly
//============================================================

Assembly :: ~Assembly(){}
	// Default Destructor



//============================================================
// Assembly::getNumber
//============================================================

int Assembly :: getNumber(void) const
	// Access function
{
	return(d_assemblyNumber);
}

//============================================================
// Assembly::getNumNodes
//============================================================

int Assembly :: getNumNodes(void) const
	// Access function
{
	int i, total;
	for(i = 0; i< d_numSurfaces; i++)
		total += (this->getSurface(i))->getNumNodes();
	return total;
}


///============================================================
// Assembly::getNumMHUnits
//============================================================

int Assembly :: getNumMHUnits(void) const
	// Access function
{
	return(this->d_numMHUnits);
}


///============================================================
// Assembly::getNumSurfaces
//============================================================

int Assembly :: getNumSurfaces(void) const
	// Access function
{
	return(this->d_numSurfaces);
}


//============================================================
// Assembly::getNumSprings
//============================================================

int Assembly :: getNumSprings(void) const
	// Access function
{
	int i, total;
	for(i = 0; i< d_numSurfaces; i++)
		total += (this->getSurface(i))->getNumSprings();
	return total;
}


//============================================================
// Assembly::isMemberOf
//============================================================

bool Assembly :: isMemberOf(Node *node) const
	// Checks if a node is a part of a assembly
{
	cout << " Not implemented" << endl;
	return true;
}



//============================================================
// Assembly::getSurface
//============================================================

Surface * Assembly :: getSurface(int surfaceNumber) const
	// Access function to surfaces
{
	return (this->d_memberSurfaces.getElement(surfaceNumber)).getData();
}



//============================================================
// Assembly::setAssemblyType
//============================================================

void Assembly :: setAssemblyType(int assemblyType)
	// Access function to surfaces
{
	d_assemblyType = assemblyType;
}


//============================================================
// Assembly::writeMHAFile
//============================================================

void Assembly :: writeMHAFile(const char *mhaFile) const
	// Access function to surfaces
{
	FILE *mhaFilePtr;
	int i;
	if((mhaFilePtr = fopen(mhaFile,"w")) == NULL)
		throw Status(3);
	else
	{
		fprintf(mhaFilePtr,"MHUnits\t");
		fprintf(mhaFilePtr,"%d\n", d_numMHUnits);
		fprintf(mhaFilePtr,"Surfaces\t");
		fprintf(mhaFilePtr,"%d\n", d_numSurfaces);
		

		fprintf(mhaFilePtr,"Materials\t");
		fprintf(mhaFilePtr,"%d\n", d_assemblyType);
		fprintf(mhaFilePtr,"\nMHU\tType\tAnch\tA\tB\tC\tX\tY\tZ\tI\tJ\tK\tL\tM\tN\n");
		Muscle *mhuPtr;
		for ( i=0; i < d_numMHUnits; i++)
		{
			mhuPtr = d_memberMHUnits.getElement(i).getData();
			mhuPtr->writeMHAFile(mhaFilePtr);
		}

		for ( i=0; i < d_numSurfaces; i++)
			(d_memberSurfaces.getElement(i).getData())->writeMHAFile(mhaFilePtr);
	}
}


//============================================================
// Assembly::getMHUnit
//============================================================

Muscle * Assembly :: getMHUnit(int mhUnitID) const
	// Access function to MH Units
{
	return (this->d_memberMHUnits.getElement(mhUnitID)).getData();
}



//============================================================
// Assembly::updateAssembly
//============================================================

void Assembly :: updateAssembly(void)
	// Updates the assembly in the correct order
{
	int i;
	for(i = 0; i < d_numMHUnits; i++)
	{
		this->getMHUnit(i)->shapeChange();
	}
	for(i = 0; i < d_numSurfaces; i++)
	{
		this->getSurface(i)->updateSurface();
	}
	for(i = 0; i < d_numMHUnits; i++)
	{
		if(!(this->getMHUnit(i)->isAnchor()))
			this->getMHUnit(i)->updateMuscle();
	}
}


#ifdef __glut_h__
//============================================================
// Assembly::display
//============================================================
void Assembly :: display(void) const
{
	// Draw the world frame

	glPushMatrix();
	glBegin(GL_LINES);
	glColor3f(1,0,0);
	glVertex3f(-10,0,0);
	glVertex3f(1000,0,0);
	glColor3f(0,1,0);
	glVertex3f(0,-10,0);
	glVertex3f(0,1000,0);
	glColor3f(0,0,1);
	glVertex3f(0,0,-10);
	glVertex3f(0,0,1000);
	glEnd();
	glPopMatrix();
	
	int i;
	for(i = 0; i < d_numMHUnits; i++)
	{
		this->getMHUnit(i)->display();
	}
	for(i = 0; i < d_numSurfaces; i++)
	{
		this->getSurface(i)->display();
	}
}

#endif

#ifndef __glut_h__
//============================================================
// Assembly::display
//============================================================
void Assembly :: display(void) const
{
	cout << " Cannot Display : GLUT libraries not installed" << endl;
	exit(1);
}

#endif
//============================================================
// operator<<
//============================================================

ostream &operator<<(ostream &output, const Assembly &assembly)
	// Overloading the << operator for easy display of Assembly information on the screen.
{
	int i;
	output << "Assembly Number: " << assembly.getNumber() << endl;
	for(i = 0; i < assembly.getNumSurfaces(); i++)
	{
		output << assembly.getSurface(i) << endl;
	}
	output << endl;
	return output;
}