//======================================================================== 
// Package			: The Sucker
// Authors			: Pradeep Setlur
// Start Date		: Mon Aug 1 2005
// Compiler			: Microsoft Visual C++ 6.0
// Acknowledgements : Biomimetic and Cognitive Robotics Laboratory,
//                    Brooklyn College, CUNY.
//                    Defense Advanced Research Projects Agency
// ----------------------------------------------------------------------  
// File: Sucker.cpp
// Implementation of the class Sucker.
//========================================================================  


#include "Sucker.hpp"


//============================================================
// Sucker::Sucker
//============================================================

Sucker::Sucker(int SuckerNumber, const char *mhaFile)
		: Assembly(SuckerNumber, mhaFile)
	// Constructor
{
	// Perform checks to verify if the the MHA file satisfies the properties of a sucker
	if (this->getNumMuscleGroups() != 5)
	{
		printf(" MHA file does not describe a sucker: Not enough muscle groups\n");
		exit(0);
	}
	if(strcmp(this->getMuscleGroup(0)->getGroupName(), "AcetabulumCap") != 0)
	{
		printf(" First Muscle group must be named \"AcetabulumCap\"\n");
		exit(0);
	}
	if(strcmp(this->getMuscleGroup(1)->getGroupName(), "Acetabulum") != 0)
	{
		printf(" Second Muscle group must be named \"Acetabulum\"\n");
		exit(0);
	}
	if(strcmp(this->getMuscleGroup(2)->getGroupName(), "Sphincter") != 0)
	{
		printf(" Third Muscle group must be named \"Sphincter\"\n");
		exit(0);
	}
	if(strcmp(this->getMuscleGroup(3)->getGroupName(), "Infundibulum") != 0)
	{
		printf(" Fourth Muscle group must be named \"Infundibulum\"\n");
		exit(0);
	}
	if(strcmp(this->getMuscleGroup(4)->getGroupName(), "ExtrinsicMuscles") != 0)
	{
		printf(" Second Muscle group must be named \"ExtrinsicMuscles\"\n");
		exit(0);
	}

}

//============================================================
// Sucker::getAcetabulumCap
//============================================================

MuscleGroup *Sucker::getAcetabulumCap(void) const
	// Access function
{
	return this->getMuscleGroup(0);
}


//============================================================
// Sucker::getAcetabulum
//============================================================

MuscleGroup *Sucker::getAcetabulum(void) const
	// Access function
{
	return this->getMuscleGroup(1);
}


//============================================================
// Sucker::getSphincter
//============================================================

MuscleGroup *Sucker::getSphincter(void) const
	// Access function
{
	return this->getMuscleGroup(2);
}

//============================================================
// Sucker::getInfundibulum
//============================================================

MuscleGroup *Sucker::getInfundibulum(void) const
	// Access function
{
	return this->getMuscleGroup(3);
}

//============================================================
// Sucker::getExtrinsicMuscles
//============================================================

MuscleGroup *Sucker::getExtrinsicMuscles(void) const
	// Access function
{
	return this->getMuscleGroup(4);
}

//============================================================
// Sucker::getInternalVoulmeOf
//============================================================

double Sucker::getInternalVolumeOf(void) const
	// Access function
{
	return 0;
}

//============================================================
// Sucker::~Sucker
//============================================================

Sucker :: ~Sucker(){}
	// Default Destructor


